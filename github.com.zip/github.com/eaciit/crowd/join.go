package crowd

func (c *Crowd) JoinDos(data interface{},
	fnKey1, fnKey2, fnOut func(interface{}) interface{}) *Crowd {
	return c
}
