package toolkit

type KvString struct {
	Key   string
	Value interface{}
}

type Kv struct {
	Key   interface{}
	Value interface{}
}
