# Toolkit

[![cover.run](https://cover.run/go/github.com/eaciit/toolkit.svg?style=flat&tag=golang-1.10)](https://cover.run/go?tag=golang-1.10&repo=github.com%2Feaciit%2Ftoolkit)

General Purpose Utility Library for Golang

### Test

```bash
$ make test
```

### Coverage Test

```bash
$ make test+coverage
```
