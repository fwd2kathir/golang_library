// +build race

package mgo

const raceDetector = true
